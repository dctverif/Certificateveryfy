# DCTVerif Version 2

Full-stack Cloudflare Pages + Pages Functions + D1 certificate verification portal.

## Features
- Public certificate verification by ID
- Direct QR verification URLs
- Admin login
- Add certificate
- Edit certificate
- Delete certificate
- Valid/Revoked status
- D1 database storage
- HTTP-only session cookie
- Password stored as SHA-256 hash in a Cloudflare secret/variable, not in website files

## IMPORTANT: Direct Upload is NOT suitable for this version
Because this project contains Pages Functions, use Git integration or Wrangler deployment. Cloudflare currently says Direct Upload is not supported with Pages Functions.

## Recommended setup

### 1. Create a D1 database
In Cloudflare Dashboard:
Workers & Pages -> D1 SQL Database -> Create Database
Name it `dctverif-db`.

Copy the database ID and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` in `wrangler.toml`.

### 2. Initialize the database
With Wrangler installed and logged in:
`npx wrangler d1 execute dctverif-db --remote --file=schema.sql`

### 3. Create your admin password hash
Run:
`node -e "const c=require('crypto'); const p=process.argv[1]; console.log(c.createHash('sha256').update(p).digest('hex'))" "YOUR-STRONG-PASSWORD"`

Copy the printed hash.

Then set it as a secret/variable named:
`ADMIN_PASSWORD_SHA256`

For production, use a Cloudflare secret rather than committing the value to source control.

### 4. Deploy
Install Wrangler if needed:
`npm install -g wrangler`

Login:
`wrangler login`

Deploy Pages:
`npx wrangler pages deploy . --project-name dctverif`

Or connect this project to GitHub in Cloudflare Pages. Pages Functions are deployed with the project.

### 5. Bind D1
If using the Cloudflare dashboard instead of the Wrangler file, go to:
Workers & Pages -> dctverif -> Settings -> Bindings -> Add -> D1 database
Variable name: `DB`
Database: `dctverif-db`
Then redeploy.

## Admin
Open:
`https://dctverif.pages.dev/admin.html`

Login with the password whose SHA-256 hash you configured.

## QR
After verifying a certificate, the page generates a QR code that points to:
`https://dctverif.pages.dev/?id=CERTIFICATE-ID`

The QR library is loaded from a CDN in this build. If you need a completely self-contained/offline build, vendor the QR library into the project.

## Security
This is designed as a practical small certificate portal. Before using it for high-stakes certificates, add stronger operational controls such as rate limiting, audit logging, recovery/admin account procedures, and a custom domain.
