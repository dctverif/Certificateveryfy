const form=document.getElementById("verifyForm"), input=document.getElementById("certificateId"), result=document.getElementById("result");
document.getElementById("year").textContent=new Date().getFullYear();
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
async function verify(id){
 result.innerHTML='<div class="result-card">Checking certificate…</div>';
 try{const r=await fetch("/api/verify?id="+encodeURIComponent(id));const d=await r.json();
 if(!r.ok||!d.certificate){result.innerHTML=`<div class="result-card"><span class="status invalid">✕ Certificate Not Found</span><h2>Unable to verify certificate</h2><p>No record was found for <b>${esc(id)}</b>.</p></div>`;return}
 const c=d.certificate; const url=location.origin+"/?id="+encodeURIComponent(c.certificate_id);
 result.innerHTML=`<div class="result-card"><span class="status ${c.status==="Valid"?"valid":"invalid"}">${c.status==="Valid"?"✓":"✕"} ${esc(c.status)}</span><h2>${c.status==="Valid"?"Certificate Verified":"Certificate Record"}</h2><div class="grid">
 <div class="item"><span class="label">Certificate ID</span><span class="value">${esc(c.certificate_id)}</span></div><div class="item"><span class="label">Status</span><span class="value">${esc(c.status)}</span></div>
 <div class="item"><span class="label">Certificate Holder</span><span class="value">${esc(c.name)}</span></div><div class="item"><span class="label">Issue Date</span><span class="value">${esc(c.issue_date)}</span></div>
 <div class="item"><span class="label">Course / Certificate</span><span class="value">${esc(c.course)}</span></div><div class="item"><span class="label">Issuing Organization</span><span class="value">${esc(c.issuer||"DCT")}</span></div></div>
 <div id="qr" class="qr"></div><small>Scan this QR code to verify this certificate again.</small></div>`;
 if(window.QRCode) new QRCode(document.getElementById("qr"),{text:url,width:150,height:150});
 }catch(e){result.innerHTML='<div class="result-card"><p class="error">Verification service is temporarily unavailable.</p></div>'}
}
form.addEventListener("submit",e=>{e.preventDefault();const id=input.value.trim().toUpperCase();if(id)verify(id)});
const q=new URLSearchParams(location.search).get("id");if(q){input.value=q;verify(q)}