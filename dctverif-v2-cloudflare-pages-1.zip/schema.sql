CREATE TABLE IF NOT EXISTS certificates (
  certificate_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  course TEXT NOT NULL,
  issue_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Valid',
  issuer TEXT NOT NULL DEFAULT 'DCT'
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

INSERT OR IGNORE INTO certificates(certificate_id,name,course,issue_date,status,issuer)
VALUES ('DCT-2026-0001','Rahul Kumar','Certificate in Computer Applications','2026-09-10','Valid','DCT');
INSERT OR IGNORE INTO certificates(certificate_id,name,course,issue_date,status,issuer)
VALUES ('DCT-2026-0002','Priya Singh','Digital Office Skills Training','2026-09-08','Valid','DCT');