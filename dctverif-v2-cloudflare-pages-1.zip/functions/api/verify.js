export async function onRequestGet({request,env}) {
 const id=(new URL(request.url).searchParams.get("id")||"").trim().toUpperCase();
 if(!id) return Response.json({error:"Certificate ID required"},{status:400});
 const c=await env.DB.prepare("SELECT certificate_id,name,course,issue_date,status,issuer FROM certificates WHERE certificate_id=?").bind(id).first();
 return Response.json({certificate:c||null});
}