const json=(d,s=200)=>Response.json(d,{status:s,headers:{"Cache-Control":"no-store"}});
async function hash(text){const b=new TextEncoder().encode(text);const h=await crypto.subtle.digest("SHA-256",b);return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function cookie(name,value,maxAge){return `${name}=${value}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Strict`}
async function auth(request,env){const m=(request.headers.get("Cookie")||"").match(/DCT_SESSION=([^;]+)/);if(!m)return null;return await env.DB.prepare("SELECT token,expires_at FROM sessions WHERE token=? AND expires_at>?").bind(m[1],Math.floor(Date.now()/1000)).first()}
async function body(request){try{return await request.json()}catch{return {}}}
export async function onRequest({request,env}) {
 const url=new URL(request.url), path=url.pathname, method=request.method;
 if(path==="/api/admin/login"&&method==="POST"){
  const {password=""}=await body(request);
  if(!env.ADMIN_PASSWORD_SHA256)return json({error:"Admin password is not configured."},500);
  const got=await hash(password);
  if(got!==String(env.ADMIN_PASSWORD_SHA256).toLowerCase())return json({error:"Invalid password."},401);
  const bytes=new Uint8Array(32);crypto.getRandomValues(bytes);const token=[...bytes].map(x=>x.toString(16).padStart(2,"0")).join("");const exp=Math.floor(Date.now()/1000)+86400;
  await env.DB.prepare("INSERT INTO sessions(token,expires_at) VALUES(?,?)").bind(token,exp).run();
  return new Response(JSON.stringify({ok:true}),{headers:{"Content-Type":"application/json","Set-Cookie":cookie("DCT_SESSION",token,86400)}});
 }
 if(path==="/api/admin/logout"&&method==="POST"){const s=await auth(request,env);if(s)await env.DB.prepare("DELETE FROM sessions WHERE token=?").bind(s.token).run();return new Response(JSON.stringify({ok:true}),{headers:{"Content-Type":"application/json","Set-Cookie":cookie("DCT_SESSION","",0)}})}
 if(path==="/api/admin/me"&&method==="GET"){if(!await auth(request,env))return json({error:"Unauthorized"},401);return json({ok:true})}
 if(path==="/api/admin/certificates"){
  if(!await auth(request,env))return json({error:"Unauthorized"},401);
  if(method==="GET"){const {results}=await env.DB.prepare("SELECT certificate_id,name,course,issue_date,status,issuer FROM certificates ORDER BY issue_date DESC,certificate_id").all();return json({certificates:results})}
  if(method==="POST"){const d=await body(request);if(!d.certificate_id||!d.name||!d.course||!d.issue_date)return json({error:"Please fill all required fields."},400);try{await env.DB.prepare("INSERT INTO certificates(certificate_id,name,course,issue_date,status,issuer) VALUES(?,?,?,?,?,?)").bind(String(d.certificate_id).trim().toUpperCase(),d.name,d.course,d.issue_date,d.status||"Valid",d.issuer||"DCT").run();return json({ok:true})}catch(e){return json({error:"Certificate ID already exists or data is invalid."},400)}}
  if(method==="PUT"){const d=await body(request);if(!d.old_id||!d.name||!d.course||!d.issue_date)return json({error:"Please fill all required fields."},400);await env.DB.prepare("UPDATE certificates SET name=?,course=?,issue_date=?,status=?,issuer=? WHERE certificate_id=?").bind(d.name,d.course,d.issue_date,d.status||"Valid",d.issuer||"DCT",String(d.old_id).trim().toUpperCase()).run();return json({ok:true})}
  if(method==="DELETE"){const id=(url.searchParams.get("id")||"").trim().toUpperCase();if(!id)return json({error:"ID required"},400);await env.DB.prepare("DELETE FROM certificates WHERE certificate_id=?").bind(id).run();return json({ok:true})}
 }
 return json({error:"Not found"},404)
}